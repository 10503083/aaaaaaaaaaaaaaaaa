﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EsotericShare.Domain.Entities
{
    public class Item
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("User")]
        public required int UserId { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public required string Content { get; set; }

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        [Required]
        public required long UnixCreatedAt { get; set; }

        [Required]
        public required int RemainingRedemptions { get; set; }

        [Required]
        public Guid RedemptionKey { get; set; } = Guid.NewGuid();
    }
}
