﻿namespace EsotericShare.Domain.Interfaces
{
    public interface ICreateReadUpdateDeleteAsync<T> : ICreateReadDeleteAsync<T>
    {
        void Update(T entity);
    }
}
