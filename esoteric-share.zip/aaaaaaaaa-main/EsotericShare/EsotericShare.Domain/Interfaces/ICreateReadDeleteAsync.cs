﻿namespace EsotericShare.Domain.Interfaces
{
    public interface ICreateReadDeleteAsync<T>
    {
        Task<T?> GetByIdAsync(int id);
        Task CreateAsync(T entity);
        void Delete(T entity);
    }
}
