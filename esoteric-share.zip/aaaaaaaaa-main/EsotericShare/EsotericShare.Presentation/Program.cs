using EsotericShare.Application.Services;
using EsotericShare.Application.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace EsotericShare.Presentation
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            var services = new ServiceCollection();

            services.AddHttpClient<IUserApiService, UserApiService>();

            var serviceProvider = services.BuildServiceProvider();

            var loginForm = new LoginForm(serviceProvider.GetService<IUserApiService>());
            var redeemForm = new RedeemForm(serviceProvider.GetService<IUserApiService>());

            loginForm.Show();
            redeemForm.Show();

            System.Windows.Forms.Application.Run();
        }
    }
}