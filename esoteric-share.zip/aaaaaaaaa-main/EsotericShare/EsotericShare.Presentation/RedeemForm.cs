﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EsotericShare.Application.Interfaces;
using EsotericShare.Application.Services;

namespace EsotericShare.Presentation
{
    public partial class RedeemForm : Form
    {
        private readonly IUserApiService _userService;

        public RedeemForm(IUserApiService userService)
        {
            _userService = userService;
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var key = textBox1.Text;

            if (string.IsNullOrEmpty(key))
            {
                MessageBox.Show("Please enter a valid key.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var redemptionResponse = await _userService.RedeemItemAsync(key);


                listView1.Items.Clear();
                listView1.Items.Add(new ListViewItem(new[] { redemptionResponse  }));

                textBox1.Clear();
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Redemption Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
                MessageBox.Show("Item no longer redeemable", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
