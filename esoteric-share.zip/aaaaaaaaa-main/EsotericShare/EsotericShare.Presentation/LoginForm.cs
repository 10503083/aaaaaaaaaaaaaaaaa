﻿using EsotericShare.Application.Interfaces;

namespace EsotericShare.Presentation
{
    public partial class LoginForm : Form
    {
        private readonly IUserApiService _userApiService;
        
        public LoginForm(IUserApiService userApiService)
        {
            _userApiService = userApiService;
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            // username box
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // password box
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var username = textBox2.Text.Trim();
            var password = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please provide both username and password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var token = await _userApiService.LoginAsync(username, password);

                Hide();
                var dashboardForm = new DashboardForm(_userApiService, token);
                dashboardForm.Show(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Login failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            // password label
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // username label
        }
    }
}
