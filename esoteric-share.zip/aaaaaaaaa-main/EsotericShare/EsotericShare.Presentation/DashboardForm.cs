﻿using EsotericShare.Application.Interfaces;

namespace EsotericShare.Presentation
{
    public partial class DashboardForm : Form
    {
        private readonly IUserApiService _userApiService;
        private string token;

        public DashboardForm(IUserApiService userApiService, string token)
        {
            _userApiService = userApiService;
            this.token = token;

            InitializeComponent();
        }

        private async void buttonCreateItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxTitleAdd.Text) || string.IsNullOrEmpty(textBoxContentAdd.Text) || string.IsNullOrEmpty(textBoxRedemptionAdd.Text))
            {
                MessageBox.Show("All fields require a value", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(textBoxRedemptionAdd.Text, out int redemptions))
            {
                MessageBox.Show("Redemptions should be an integer", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var success = await _userApiService.CreateItemAsync(token, textBoxTitleAdd.Text, textBoxContentAdd.Text, redemptions);

                if (!success)
                {
                    MessageBox.Show("Failed to create item ):", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                MessageBox.Show("Item created successfully !", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                await LoadList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"y {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void DashboardForm_Load(object sender, EventArgs e)
        {
            await LoadList();
        }

        private async Task LoadList()
        {
            try
            {
                var items = await _userApiService.RetrieveAllUserKeysAsync(token);

                dataGridView1.Rows.Clear();

                foreach (var item in items)
                {
                    DateTime date = DateTimeOffset.FromUnixTimeSeconds(item.UnixCreatedAt).DateTime;

                    string[] row = new string[]
                    {
                        item.Title,
                        item.RemainingRedemptions.ToString(),
                        date.ToString("yyyy-MM-dd HH:mm:ss"),
                        item.Id.ToString(),
                        item.RedemptionKey.ToString()
                    };

                    dataGridView1.Rows.Add(row);
                    dataGridView1.Columns["ColumnKey"].Width = 250;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"item error {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await LoadList();
        }
    }
}
