﻿namespace EsotericShare.Presentation
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonCreateItem = new Button();
            textBoxTitleAdd = new TextBox();
            textBoxContentAdd = new TextBox();
            textBoxRedemptionAdd = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            ColumnTitle = new DataGridViewTextBoxColumn();
            ColumnRemaining = new DataGridViewTextBoxColumn();
            ColumnDate = new DataGridViewTextBoxColumn();
            ColumnId = new DataGridViewTextBoxColumn();
            ColumnKey = new DataGridViewTextBoxColumn();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // buttonCreateItem
            // 
            buttonCreateItem.Location = new Point(10, 226);
            buttonCreateItem.Name = "buttonCreateItem";
            buttonCreateItem.Size = new Size(172, 46);
            buttonCreateItem.TabIndex = 0;
            buttonCreateItem.Text = "Create";
            buttonCreateItem.UseVisualStyleBackColor = true;
            buttonCreateItem.Click += buttonCreateItem_Click;
            // 
            // textBoxTitleAdd
            // 
            textBoxTitleAdd.Location = new Point(12, 52);
            textBoxTitleAdd.Name = "textBoxTitleAdd";
            textBoxTitleAdd.Size = new Size(174, 23);
            textBoxTitleAdd.TabIndex = 1;
            // 
            // textBoxContentAdd
            // 
            textBoxContentAdd.Location = new Point(10, 114);
            textBoxContentAdd.Name = "textBoxContentAdd";
            textBoxContentAdd.Size = new Size(174, 23);
            textBoxContentAdd.TabIndex = 2;
            // 
            // textBoxRedemptionAdd
            // 
            textBoxRedemptionAdd.Location = new Point(10, 180);
            textBoxRedemptionAdd.Name = "textBoxRedemptionAdd";
            textBoxRedemptionAdd.Size = new Size(172, 23);
            textBoxRedemptionAdd.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 24);
            label1.Name = "label1";
            label1.Size = new Size(29, 15);
            label1.TabIndex = 4;
            label1.Text = "Title";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 87);
            label2.Name = "label2";
            label2.Size = new Size(50, 15);
            label2.TabIndex = 5;
            label2.Text = "Content";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 153);
            label3.Name = "label3";
            label3.Size = new Size(77, 15);
            label3.TabIndex = 6;
            label3.Text = "Redemptions";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ColumnTitle, ColumnRemaining, ColumnDate, ColumnId, ColumnKey });
            dataGridView1.Location = new Point(221, 42);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(543, 230);
            dataGridView1.TabIndex = 7;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // ColumnTitle
            // 
            ColumnTitle.HeaderText = "Title";
            ColumnTitle.Name = "ColumnTitle";
            ColumnTitle.ReadOnly = true;
            // 
            // ColumnRemaining
            // 
            ColumnRemaining.HeaderText = "Remaining";
            ColumnRemaining.Name = "ColumnRemaining";
            ColumnRemaining.ReadOnly = true;
            // 
            // ColumnDate
            // 
            ColumnDate.HeaderText = "Date";
            ColumnDate.Name = "ColumnDate";
            ColumnDate.ReadOnly = true;
            // 
            // ColumnId
            // 
            ColumnId.HeaderText = "ID";
            ColumnId.Name = "ColumnId";
            ColumnId.ReadOnly = true;
            // 
            // ColumnKey
            // 
            ColumnKey.HeaderText = "Key";
            ColumnKey.Name = "ColumnKey";
            ColumnKey.ReadOnly = true;
            // 
            // button1
            // 
            button1.Location = new Point(10, 278);
            button1.Name = "button1";
            button1.Size = new Size(172, 33);
            button1.TabIndex = 8;
            button1.Text = "Refresh";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // DashboardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(809, 341);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxRedemptionAdd);
            Controls.Add(textBoxContentAdd);
            Controls.Add(textBoxTitleAdd);
            Controls.Add(buttonCreateItem);
            Name = "DashboardForm";
            Text = "DashboardForm";
            Load += DashboardForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonCreateItem;
        private TextBox textBoxTitleAdd;
        private TextBox textBoxContentAdd;
        private TextBox textBoxRedemptionAdd;
        private Label label1;
        private Label label2;
        private Label label3;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn ColumnTitle;
        private DataGridViewTextBoxColumn ColumnRemaining;
        private DataGridViewTextBoxColumn ColumnDate;
        private DataGridViewTextBoxColumn ColumnId;
        private DataGridViewTextBoxColumn ColumnKey;
        private Button button1;
    }
}