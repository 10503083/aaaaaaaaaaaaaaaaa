﻿using EsotericShare.Application.DTOs;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Application.Interfaces
{
    public interface IMapperService
    {
        TDestination Map<TSource, TDestination>(TSource source);
        void Map(ItemUpdateDto patch, Item item);
    }
}
