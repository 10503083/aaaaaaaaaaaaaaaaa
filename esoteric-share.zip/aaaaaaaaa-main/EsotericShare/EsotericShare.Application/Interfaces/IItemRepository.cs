﻿using EsotericShare.Application.DTOs;
using EsotericShare.Domain.Entities;
using EsotericShare.Domain.Interfaces;

namespace EsotericShare.Application.Interfaces
{
    public interface IItemRepository : ICreateReadUpdateDeleteAsync<Item>
    {
        Task SaveChangesAsync();
        Task<IEnumerable<ItemReadDto>> GetAllUserItemsAsync(int id);
        Task<Item?> GetByRedemptionKeyAsync(Guid redemptionKey);
        Task<bool> RedeemItemAsync(Guid redemptionKey);
    }
}
