﻿using EsotericShare.Domain.Entities;
using EsotericShare.Domain.Interfaces;

namespace EsotericShare.Application.Interfaces
{
    public interface IUserRepository : ICreateReadDeleteAsync<User>
    {
        Task SaveChangesAsync();
        Task<User?> GetUserByNameAsync(string name);
    }
}
