﻿using EsotericShare.Application.DTOs;

namespace EsotericShare.Application.Interfaces
{
    public interface IUserApiService
    {
        Task<UserReadDto> GetUserAsync();
        Task<string> LoginAsync(string username, string password);
        Task<IEnumerable<ItemReadDto>> RetrieveAllUserKeysAsync(string token);
        Task<bool> CreateItemAsync(string token, string title, string content, int redemptions);
        Task<string> RedeemItemAsync(string key);
    }
}
