﻿using EsotericShare.Application.DTOs;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Application.Interfaces
{
    public interface IItemService
    {
        Task<IEnumerable<ItemReadDto>> GetAllUserItemsAsync(string? idAsString);
        Task<ItemReadDto?> GetItemAsync(string? idAsString, int id);
        Task<ItemReadDto?> CreateItemAsync(string? idAsString, ItemCreateDto itemCreateDto);
        ItemUpdateDto? UpdateItemPart1(Item item, string? idAsString);
        Task UpdateItemAsyncPart2(ItemUpdateDto patch, Item item);
        Task<bool> DeleteItemAsync(int id, string? idAsString);
        Task<Item?> GetFullItemAsync(int id);
        Task<ItemReadDto> RedeemItemAsync(Guid key);
    }
}
