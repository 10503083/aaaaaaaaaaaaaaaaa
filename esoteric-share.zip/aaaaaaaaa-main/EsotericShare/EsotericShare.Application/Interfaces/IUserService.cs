﻿using EsotericShare.Application.DTOs;

namespace EsotericShare.Application.Interfaces
{
    public interface IUserService
    {
        Task<UserReadDto> CreateUserAsync(UserCreateDto userCreateDto);
        Task<UserReadDto?> GetUserAsync(int id);
        Task<bool> DeleteUserAsync(string? userIdAsString);
    }
}
