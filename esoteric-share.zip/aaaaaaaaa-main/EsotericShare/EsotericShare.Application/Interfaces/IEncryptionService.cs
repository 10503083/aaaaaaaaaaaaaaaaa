﻿namespace EsotericShare.Application.Interfaces
{
    public interface IEncryptionService
    {
        public string EncryptText(string plainText);
        public string DecryptText(string cipherText);
    }
}
