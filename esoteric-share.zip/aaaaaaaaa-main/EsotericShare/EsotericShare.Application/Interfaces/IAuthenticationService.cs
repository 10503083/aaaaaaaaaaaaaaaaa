﻿using EsotericShare.Application.DTOs;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Application.Interfaces
{
    public interface IAuthenticationService
    {
        Task<string?> LoginAsync(string username, string password);
        Task<UserReadDto?> GetUserAsync(string? idAsString);
        string GenerateToken(User user, TimeSpan time);
    }
}
