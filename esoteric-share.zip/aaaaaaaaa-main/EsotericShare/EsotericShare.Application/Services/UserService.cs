﻿using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Application.Services
{
    public class UserService(IUserRepository userRepository, IMapperService mapperService, IHashingService hashingService) : IUserService
    {
        private readonly IUserRepository _userRepository = userRepository;
        private readonly IMapperService _mapperService = mapperService;
        private readonly IHashingService _hashingService = hashingService;
        public async Task<UserReadDto> CreateUserAsync(UserCreateDto userCreateDto)
        {
            var exists = await _userRepository.GetUserByNameAsync(userCreateDto.Username);
            if (exists != null)
            {
                throw new InvalidOperationException("Username already exists.");
            }

            var passwordAsHash = _hashingService.HashPassword(userCreateDto.Password);
            var user = new User
            {
                Username = userCreateDto.Username,
                HashedPassword = passwordAsHash
            };

            await _userRepository.CreateAsync(user);
            await _userRepository.SaveChangesAsync();

            return _mapperService.Map<User, UserReadDto>(user);
        }

        public async Task<UserReadDto?> GetUserAsync(int id)
        {
            var user = await _userRepository.GetByIdAsync(id);
            if (user == null)
            {
                return null;
            }

            return _mapperService.Map<User, UserReadDto>(user);
        }

        public async Task<bool> DeleteUserAsync(string? userIdAsString)
        {
            if (userIdAsString == null)
            {
                return false;
            }

            if (!int.TryParse(userIdAsString, out int userId))
            {
                return false;
            }

            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
            {
                return false;
            }

            _userRepository.Delete(user);
            await _userRepository.SaveChangesAsync();

            return true;
        }
    }
}
