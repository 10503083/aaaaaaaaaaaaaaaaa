﻿using System.Net.Http.Headers;
using System.Text;
using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace EsotericShare.Application.Services
{
    public class UserApiService(HttpClient httpClient) : IUserApiService
    {
        private readonly HttpClient _httpClient = httpClient;
        private readonly string _apiBaseUrl = "https://localhost:7282";
        private readonly string _apiUsersRoute = "api/latests/users";
        private readonly string _apiAuthenticationsRoute = "api/latests/authentications";
        private readonly string _apiItemRoute = "api/latests/items";

        public async Task<bool> CreateItemAsync(string token, string title, string content, int redemptions)
        {
            var itemCreateDto = new ItemCreateDto
            {
                Title = title,
                Content = content,
                RemainingRedemptions = redemptions
            };

            var serializedContent = new StringContent(JsonConvert.SerializeObject(itemCreateDto), Encoding.UTF8, "application/json");

            var requestUrl = $"{_apiBaseUrl}/{_apiItemRoute}";

            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.PostAsync(requestUrl, serializedContent);

            return response.IsSuccessStatusCode;
        }


        public async Task<UserReadDto> GetUserAsync()
        {
            var response = await _httpClient.GetAsync($"{_apiBaseUrl}/{_apiUsersRoute}/2");
            
            response.EnsureSuccessStatusCode();

            var user = await response.Content.ReadAsAsync<UserReadDto>();

            return user;
        }

        public async Task<string> LoginAsync(string username, string password)
        {
            var loginDto = new UserLoginDto 
            { 
                Username = username,
                Password = password 
            };

            var content = new StringContent(JsonConvert.SerializeObject(loginDto), Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync($"{_apiBaseUrl}/{_apiAuthenticationsRoute}", content);

            response.EnsureSuccessStatusCode();

            var token = await response.Content.ReadAsStringAsync();

            return token;
        }

        public async Task<string> RedeemItemAsync(string key)
        {
            var url = $"{_apiBaseUrl}/{_apiItemRoute}/redeem/{key}";

            var response = await _httpClient.PostAsync(url, null);

            response.EnsureSuccessStatusCode();

            var itemReadDto = await response.Content.ReadAsAsync<ItemReadDto>();

            return itemReadDto.Content;
        }


        public async Task<IEnumerable<ItemReadDto>> RetrieveAllUserKeysAsync(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

            var response = await _httpClient.GetAsync($"{_apiBaseUrl}/{_apiItemRoute}/user");

            response.EnsureSuccessStatusCode();

            var items = await response.Content.ReadAsAsync<IEnumerable<ItemReadDto>>();

            return items;
        }
    }
}
