﻿using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Application.Services
{
    public class ItemService(IItemRepository itemRepository, IMapperService mapperService) : IItemService
    {
        private readonly IItemRepository _itemRepository = itemRepository;
        private readonly IMapperService _mapperService = mapperService;

        public async Task<ItemReadDto?> CreateItemAsync(string? idAsString, ItemCreateDto itemCreateDto)
        {
            if (idAsString == null)
            {
                return null;
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return null;
            }

            var unixTimestamp = ((DateTimeOffset)DateTime.UtcNow).ToUnixTimeSeconds();

            var item = new Item
            {
                Title = itemCreateDto.Title,
                Content = itemCreateDto.Content,
                UnixCreatedAt = unixTimestamp,
                RemainingRedemptions = itemCreateDto.RemainingRedemptions,
                UserId = userId
            };

            await _itemRepository.CreateAsync(item);
            await _itemRepository.SaveChangesAsync();

            var itemReadDto = _mapperService.Map<Item, ItemReadDto>(item);

            return itemReadDto;
        }

        public async Task<IEnumerable<ItemReadDto>> GetAllUserItemsAsync(string? idAsString)
        {
            if (idAsString == null)
            {
                return [];
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return [];
            }

            return await _itemRepository.GetAllUserItemsAsync(userId);
        }

        public async Task<ItemReadDto?> GetItemAsync(string? idAsString, int id)
        {
            if (idAsString == null)
            {
                return null;
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return null;
            }

            var item = await _itemRepository.GetByIdAsync(id);

            if (item == null)
            {
                return null;
            }

            if (item.UserId != userId)
            {
                return null;
            }

            return _mapperService.Map<Item, ItemReadDto>(item);
        }

        public ItemUpdateDto? UpdateItemPart1(Item item, string? idAsString)
        {
            if (idAsString == null)
            {
                return null;
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return null;
            }

            if (item.UserId != userId)
            {
                return null;
            }

            return _mapperService.Map<Item, ItemUpdateDto>(item);
        }

        public async Task UpdateItemAsyncPart2(ItemUpdateDto patch, Item item)
        {
            _mapperService.Map(patch, item);

            await _itemRepository.SaveChangesAsync();
        }

        public async Task<Item?> GetFullItemAsync(int id)
        {
            return await _itemRepository.GetByIdAsync(id);
        }

        public async Task<bool> DeleteItemAsync(int id, string? idAsString)
        {
            var item = await _itemRepository.GetByIdAsync(id);
            if (item == null)
            {
                return false;
            }

            if (idAsString == null)
            {
                return false;
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return false;
            }

            if (item.UserId != userId)
            {
                return false;
            }

            _itemRepository.Delete(item);
            await _itemRepository.SaveChangesAsync();

            return true;
        }

        public async Task<ItemReadDto> RedeemItemAsync(Guid key)
        {
            var success = await _itemRepository.RedeemItemAsync(key);

            if (!success)
            {
                throw new InvalidOperationException("Item not found, no remaining redemptions, or concurrency conflict.");
            }

            var redeemedItem = await _itemRepository.GetByRedemptionKeyAsync(key);

            return _mapperService.Map<Item, ItemReadDto>(redeemedItem!);
        }
    }
}