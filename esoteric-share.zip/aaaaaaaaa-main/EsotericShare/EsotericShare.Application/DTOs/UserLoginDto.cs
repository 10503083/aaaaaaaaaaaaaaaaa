﻿using System.ComponentModel.DataAnnotations;

namespace EsotericShare.Application.DTOs
{
    public class UserLoginDto
    {
        [Required]
        public required string Username { get; set; }

        [Required]
        public required string Password { get; set; }
    }
}
