﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EsotericShare.Application.DTOs
{
    public class ItemReadDto
    {
        [Key]
        public int Id { get; set; }
        [ForeignKey("User")]
        public required int UserId { get; set; }

        [Required]
        public required string Title { get; set; }

        [Required]
        public required string Content { get; set; }

        [Required]
        public long UnixCreatedAt { get; set; }

        [Required]
        public int RemainingRedemptions { get; set; }
        [Required]
        public Guid RedemptionKey { get; set; } = Guid.NewGuid();
    }
}
