﻿using System.ComponentModel.DataAnnotations;

namespace EsotericShare.Application.DTOs
{
    public class UserReadDto
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public required string Username { get; set; }
    }
}
