﻿using System.ComponentModel.DataAnnotations;

namespace EsotericShare.Application.DTOs
{
    public class ItemUpdateDto
    {
        [Required]
        public required string Title { get; set; }

        [Required]
        public required string Content { get; set; }

        [Required]
        public required int RemainingRedemptions { get; set; }
    }
}
