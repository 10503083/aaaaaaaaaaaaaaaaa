﻿using EsotericShare.Domain.Entities;
using EsotericShare.Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace EsotericShare.Infrastructure.Data
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;
        public UserRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task CreateAsync(User entity)
        {
            ArgumentNullException.ThrowIfNull(entity);

            await _context.Users.AddAsync(entity);
        }

        public void Delete(User entity)
        {
            ArgumentNullException.ThrowIfNull(entity);

            _context.Users.Remove(entity);
        }

        public async Task<User?> GetByIdAsync(int id)
        {
            return await _context.Users.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<User?> GetUserByNameAsync(string name)
        {
            return await _context.Users.FirstOrDefaultAsync(x => x.Username == name);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}
