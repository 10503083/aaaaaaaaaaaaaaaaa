﻿using EsotericShare.Domain.Entities;
using EsotericShare.Application.Interfaces;
using Microsoft.EntityFrameworkCore;
using EsotericShare.Application.DTOs;

namespace EsotericShare.Infrastructure.Data
{
    public class ItemRepository(AppDbContext context, IMapperService mapperService) : IItemRepository
    {
        private readonly AppDbContext _context = context;
        private readonly IMapperService _mapperService = mapperService;

        public async Task CreateAsync(Item entity)
        {
            ArgumentNullException.ThrowIfNull(entity);

            await _context.Items.AddAsync(entity);
        }

        public void Update(Item entity)
        {
            _context.Items.Update(entity);
        }

        public void Delete(Item entity)
        {
            ArgumentNullException.ThrowIfNull(entity);
            _context.Items.Remove(entity);
        }

        public async Task<IEnumerable<ItemReadDto>> GetAllUserItemsAsync(int id)
        {
            var userItems = await _context.Items
            .Where(item => item.UserId == id)
            .Select(item => _mapperService.Map<Item, ItemReadDto>(item))
            .ToListAsync();

            return userItems ?? Enumerable.Empty<ItemReadDto>();
        }

        public async Task<Item?> GetByIdAsync(int id)
        {
            return await _context.Items.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<Item?> GetByRedemptionKeyAsync(Guid redemptionKey)
        {
            return await _context.Items
                .Where(item => item.RedemptionKey == redemptionKey)
                .FirstOrDefaultAsync();
        }

        public async Task<bool> RedeemItemAsync(Guid redemptionKey)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                var item = await GetByRedemptionKeyAsync(redemptionKey);

                if (item == null || item.RemainingRedemptions <= 0)
                {
                    return false; 
                }

                var originalRowVersion = item.RowVersion;
                var currentItem = await GetByIdAsync(item.Id);

                if (currentItem == null ||
                    currentItem.RowVersion == null ||
                    originalRowVersion == null ||
                    !currentItem.RowVersion.SequenceEqual(originalRowVersion))
                {
                    throw new DbUpdateConcurrencyException("bad yo");
                }

                currentItem.RemainingRedemptions--;

                Update(currentItem);

                await SaveChangesAsync();

                await transaction.CommitAsync();

                return true;
            }
            catch
            {
                await transaction.RollbackAsync();
                throw; 
            }
        }
    }
}
