﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace EsotericShare.Infrastructure.Data
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        public AppDbContext CreateDbContext(string[] args)
        {
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Path.Combine(Directory.GetCurrentDirectory(), "..", "EsotericShare.API")) 
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)  
                .AddUserSecrets<DesignTimeDbContextFactory>() 
                .Build();

            var userId = configuration["UserId"];
            var password = configuration["Password"];
            var connectionString = configuration.GetConnectionString("AppContextConnection");

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(connectionString))
            {
                throw new Exception("Missing required configuration values.");
            }

            var sqlConnectionBuilder = new SqlConnectionStringBuilder
            {
                ConnectionString = connectionString,
                UserID = userId,
                Password = password
            };
            sqlConnectionBuilder["TrustServerCertificate"] = "True";

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseSqlServer(sqlConnectionBuilder.ConnectionString);

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}
