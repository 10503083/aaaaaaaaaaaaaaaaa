﻿using AutoMapper;
using EsotericShare.Application.DTOs;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Infrastructure.Profiles
{
    public class ItemProfile : Profile
    {
        public ItemProfile()
        {
            CreateMap<ItemCreateDto, Item>()
             .ForMember(dest => dest.UnixCreatedAt, opt => opt.MapFrom(src => ((DateTimeOffset)DateTime.UtcNow).ToUnixTimeSeconds()));

            CreateMap<Item, ItemReadDto>()
            .ForMember(dest => dest.UnixCreatedAt, opt => opt.MapFrom(src => src.UnixCreatedAt));

            CreateMap<ItemUpdateDto, Item>();
            CreateMap<Item, ItemUpdateDto>();
        }
    }
}
