﻿using System.Text;
using EsotericShare.Application.Interfaces;
using EsotericShare.Application.Services;
using EsotericShare.Infrastructure.Data;
using EsotericShare.Infrastructure.Profiles;
using EsotericShare.Infrastructure.Services;
using Infrastructure.Profiles;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;

namespace EsotericShare.Infrastructure
{
    public static class ServiceRegistration
    {
        public static void AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x =>
            {
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidIssuer = configuration["JwtSettings:Issuer"],
                    ValidAudience = configuration["JwtSettings:Audience"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["PrivateKey"]!)),
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true
                };
            });

            services.AddAuthorization();

            services.AddControllers().AddNewtonsoftJson(s =>
            {
                s.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
            });

            var sqlConnectionBuilder = new SqlConnectionStringBuilder
            {
                ConnectionString = configuration.GetConnectionString("AppContextConnection"),
                UserID = configuration["UserId"],
                Password = configuration["Password"]
            };
            sqlConnectionBuilder["TrustServerCertificate"] = "True";

            services.AddDbContext<AppDbContext>(opt => opt.UseSqlServer(sqlConnectionBuilder.ConnectionString));

            services.AddAutoMapper(typeof(UserProfile).Assembly, typeof(ItemProfile).Assembly);
            
            services.AddScoped<IMapperService, AutoMapperService>();
            services.AddScoped<IHashingService, BCrypthashingService>();
            services.AddScoped<IAuthenticationService, JwtAuthenticationService>();
            services.AddScoped<IEncryptionService, AesEncryptionService>();

            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IItemRepository, ItemRepository>();

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IItemService, ItemService>();
        }
    }
}
