﻿using System.Security.Cryptography;
using System.Text;
using EsotericShare.Application.Interfaces;
using Microsoft.Extensions.Configuration;

namespace EsotericShare.Infrastructure.Services
{
    public class AesEncryptionService(IConfiguration configuration) : IEncryptionService
    {
        private readonly IConfiguration _configuration = configuration;

        public string EncryptText(string plainText)
        {
            using Aes aesAlg = Aes.Create();

            byte[] key = Encoding.UTF8.GetBytes(_configuration["AESK"]!);
            byte[] iv = Encoding.UTF8.GetBytes(_configuration["IV"]!);

            if (key.Length != 16 && key.Length != 24 && key.Length != 32)
            {
                throw new ArgumentException("Invalid key length. It must be 16, 24, or 32 bytes.");
            }

            if (iv.Length != 16)
            {
                throw new ArgumentException("Invalid IV length. It must be 16 bytes.");
            }

            aesAlg.Key = key;
            aesAlg.IV = iv;

            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

            using var ms = new MemoryStream();

            using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            {
                using var sw = new StreamWriter(cs);
                sw.Write(plainText);
            }

            return Convert.ToBase64String(ms.ToArray());
        }

        public string DecryptText(string cipherText)
        {
            using Aes aesAlg = Aes.Create();

            byte[] key = Encoding.UTF8.GetBytes(_configuration["AESK"]!);
            byte[] iv = Encoding.UTF8.GetBytes(_configuration["IV"]!);

            if (key.Length != 16 && key.Length != 24 && key.Length != 32)
            {
                throw new ArgumentException("Invalid key length. It must be 16, 24, or 32 bytes.");
            }

            if (iv.Length != 16)
            {
                throw new ArgumentException("Invalid IV length. It must be 16 bytes.");
            }

            aesAlg.Key = key;
            aesAlg.IV = iv;

            ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

            using var ms = new MemoryStream(Convert.FromBase64String(cipherText));
            using var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read);
            using var sr = new StreamReader(cs);

            return sr.ReadToEnd();
        }

    }
}
