﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using EsotericShare.Domain.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace EsotericShare.Infrastructure.Services
{
    public class JwtAuthenticationService(IConfiguration configuration, IHashingService hashingService, IUserRepository userRepository, IMapperService mapperService) : IAuthenticationService
    {
        private readonly IConfiguration _configuration = configuration;
        private readonly IHashingService _hashingService = hashingService;
        private readonly IUserRepository _userRepository = userRepository;
        private readonly IMapperService _mapperService = mapperService;
        public string GenerateToken(User user, TimeSpan time)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var keyAsBytes = Encoding.UTF8.GetBytes(_configuration["PrivateKey"]!);
            var securityKey = new SymmetricSecurityKey(keyAsBytes);

            var claims = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString())
            });

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = claims,
                Expires = DateTime.UtcNow.Add(time),
                Issuer = _configuration["JwtSettings:Issuer"],
                Audience = _configuration["JwtSettings:Audience"],
                SigningCredentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public async Task<UserReadDto?> GetUserAsync(string? idAsString)
        {
            if (idAsString == null)
            {
                return null;
            }

            if (!int.TryParse(idAsString, out int userId))
            {
                return null;
            }

            var user = await _userRepository.GetByIdAsync(userId);
            return user == null ? null : _mapperService.Map<User, UserReadDto>(user);
        }

        public async Task<string?> LoginAsync(string username, string password)
        {
            var user = await _userRepository.GetUserByNameAsync(username);

            if (user == null || !_hashingService.VerifyPassword(user.HashedPassword, password))
            {
                return null;
            }

            var token = GenerateToken(user, TimeSpan.FromMinutes(10));

            return token;
        }
    }
}
