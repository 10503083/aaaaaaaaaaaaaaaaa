﻿using AutoMapper;
using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using EsotericShare.Domain.Entities;

namespace EsotericShare.Infrastructure.Services
{
    public class AutoMapperService(IMapper mapper) : IMapperService
    {
        private readonly IMapper _mapper = mapper;

        public TDestination Map<TSource, TDestination>(TSource source)
        {
            return _mapper.Map<TDestination>(source);
        }

        public void Map(ItemUpdateDto patch, Item item)
        {
            _mapper.Map(patch, item);
        }
    }
}
