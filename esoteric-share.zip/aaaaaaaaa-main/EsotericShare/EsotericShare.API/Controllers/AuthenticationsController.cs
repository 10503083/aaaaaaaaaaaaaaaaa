﻿using EsotericShare.Application.DTOs;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using EsotericShare.Application.Interfaces;

namespace EsotericShare.API.Controllers
{
    [Route("api/latests/[controller]")]
    [ApiController]
    public class AuthenticationsController(IAuthenticationService authenticationService) : ControllerBase
    {
        private readonly IAuthenticationService _authenticationService = authenticationService;

        [HttpPost]
        public async Task<ActionResult> LoginAsync(UserLoginDto loginDto)
        {
            if (loginDto == null) {
                return BadRequest();
            }

            var token = await _authenticationService.LoginAsync(loginDto.Username, loginDto.Password);

            if (token == null)
            {
                return Unauthorized();
            }

            return Ok(token);
        }

        [Authorize]
        [HttpGet]
        public async Task<ActionResult<UserReadDto>> GetUserAsync()
        {
            var user = await _authenticationService.GetUserAsync(User.FindFirstValue(ClaimTypes.NameIdentifier));
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }
    }
}
