﻿using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace EsotericShare.API.Controllers
{
    [Route("api/latests/[controller]")]
    [ApiController]
    public class UsersController(IUserService userService) : ControllerBase
    {
        private readonly IUserService _userService = userService;

        // auth?
        [HttpGet("{id}", Name = "GetUserAsync")]
        public async Task<ActionResult<UserReadDto>> GetUserAsync(int id)
        {
            var userReadDto = await _userService.GetUserAsync(id);

            if (userReadDto == null)
            {
                return NotFound();
            }

            return Ok(userReadDto);
        }

        [HttpPost]
        public async Task<ActionResult<UserReadDto>> CreateUserAsync(UserCreateDto userCreateDto)
        {
            try
            {
                var userReadDto = await _userService.CreateUserAsync(userCreateDto);
                return CreatedAtRoute(nameof(GetUserAsync), new { Id = userReadDto.Id }, userReadDto);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpDelete]
        public async Task<ActionResult> DeleteUserAsync()
        {
            var isDeleted = await _userService.DeleteUserAsync(User.FindFirstValue(ClaimTypes.NameIdentifier));

            return isDeleted ? NoContent() : NotFound();
        }
    }
}
