﻿using System.Security.Claims;
using EsotericShare.Application.DTOs;
using EsotericShare.Application.Interfaces;
using EsotericShare.Domain.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EsotericShare.API.Controllers
{
    [Route("api/latests/[controller]")]
    [ApiController]
    public class ItemsController(IItemService itemService) : ControllerBase
    {
        private readonly IItemService _itemService = itemService;

        [Authorize]
        [HttpGet("user")]
        public async Task<ActionResult> GetAllUserItemsAsync()
        {
            var items = await _itemService.GetAllUserItemsAsync(User.FindFirstValue(ClaimTypes.NameIdentifier));

            return Ok(items);
        }

        [Authorize]
        [HttpGet("{id}", Name = "GetItemAsync")]
        public async Task<ActionResult<ItemReadDto>> GetItemAsync(int id)
        {
            var item = await _itemService.GetItemAsync(User.FindFirstValue(ClaimTypes.NameIdentifier), id);

            if (item == null)
            {
                return Ok();
            }

            return Ok(item);
        }

        [Authorize]
        [HttpPost]
        public async Task<ActionResult<ItemReadDto>> CreateItemAsync(ItemCreateDto itemCreateDto)
        {
            var itemReadDto = await _itemService.CreateItemAsync(User.FindFirstValue(ClaimTypes.NameIdentifier), itemCreateDto);

            if (itemReadDto == null)
            {
                return BadRequest("hm");
            }

            return CreatedAtRoute(nameof(GetItemAsync), new { Id = itemReadDto }, itemReadDto);
        }

        [HttpPost("redeem/{key}")]
        public async Task<ActionResult<ItemReadDto>> RedeemItem(Guid key)
        {
            try
            {
                var itemReadDto = await _itemService.RedeemItemAsync(key);
                return Ok(itemReadDto);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (DbUpdateConcurrencyException)
            {
                return Conflict("The item has already been redeemed or modified by another user.");
            }
        }


        [HttpPatch("{id}")]
        public async Task<ActionResult> UpdateItemAsync(int id, JsonPatchDocument<ItemUpdateDto> patchDocument)
        {
            var item = await _itemService.GetFullItemAsync(id);

            if (item == null)
            {
                return NotFound();
            }

            var patch = _itemService.UpdateItemPart1(item, User.FindFirstValue(ClaimTypes.NameIdentifier));

            if (patch == null)
            {
                return NotFound();
            }

            patchDocument.ApplyTo(patch, ModelState);

            if (!TryValidateModel(patch))
            {
                return ValidationProblem(ModelState);
            }

            await _itemService.UpdateItemAsyncPart2(patch, item);

            return NoContent();
        }

        [Authorize]
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteItemAsync(int id)
        {
            var delete = await _itemService.DeleteItemAsync(id, User.FindFirstValue(ClaimTypes.NameIdentifier));
            return delete ? NoContent() : BadRequest();
        }
    }
}
